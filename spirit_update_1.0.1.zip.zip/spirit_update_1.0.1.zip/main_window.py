from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QTabWidget,
    QPushButton, QFrame, QGraphicsDropShadowEffect, QSizePolicy,QStackedWidget
)
from PyQt6.QtCore import QPropertyAnimation, QEasingCurve, QPoint
from core.refresh_notifier import refresh_notifier
from PyQt6.QtGui import QColor, QIcon
from PyQt6.QtCore import Qt, QSize
from ui.add_product import AddProductPage
from ui.add_customer import AddCustomerPage  
from ui.invoice_window import InvoiceWindow 
from ui.invoice_manager import InvoiceManager 
from ui.settings_page import SettingsPage 
from ui.add_user_window import AddUserPage 
from core.resource_path import resource_path
from PyQt6.QtCore import QTimer


#UPDATER DON
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("🚀 سبرت منجر - إدارة المنتجات")

        self.resize(1300, 650)
        self.setMinimumSize(830, 500)

        self.center_window()
        self.init_ui()
        self.apply_styles()

    def init_ui(self):
        # التابز
        self.setContentsMargins(0,0,0,0)
        self.stacked_widget = QStackedWidget()
        self.tabs = QTabWidget()
        self.tabs.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        # إنشاء التبويبات
        self.home_tab = QWidget()
        self.product_tab = AddProductPage()
        self.invoice_tab = InvoiceWindow()
        self.customer_tab = AddCustomerPage()
        self.invoice_manager = InvoiceManager()
        self.settings_page = SettingsPage()
        self.adduser_page = AddUserPage()
            

        def delayed_refresh(page, delay_ms):
            QTimer.singleShot(delay_ms, page.refresh_db)

        def connect_refresh_with_delay(pages, step_ms=250):
            for i, page in enumerate(pages):
                delay = i * step_ms
                # نربط كل صفحة بدالة تؤخر التنفيذ عند إطلاق الإشارة
                refresh_notifier.refresh_signal.connect(lambda p=page, d=delay: delayed_refresh(p, d))

        connect_refresh_with_delay([
                                        self.product_tab,
                                        self.customer_tab,
                                        self.invoice_tab,
                                        self.invoice_manager,
                                        self.adduser_page
                                    ])



        # إضافة التبويبات
        self.tabs.addTab(self.home_tab, "🏠 الرئيسية")
        self.tabs.addTab(self.product_tab, "📦 إدارة المنتجات")
        self.tabs.addTab(self.invoice_tab, "🧾 الفواتير")
        self.tabs.addTab(self.customer_tab, "🧑‍💼 إدارة الزبائن")
        self.tabs.addTab(self.invoice_manager, "📄 إدارة الفواتير")
        
        # ✅ شريط الأيقونات الجانبي
        self.sidebar = QFrame()
        self.sidebar.setFixedWidth(40)

        self.sidebar.setStyleSheet("background-color: #E3ECF5; border-right: 2px solid #007AFF; padding:0px;")
        
        sidebar_layout = QVBoxLayout()
        sidebar_layout.setContentsMargins(2, 10, 5, 0)  
        sidebar_layout.setSpacing(5)  # ✅ المسافة بين العناصر 5


        sidebar_layout.setAlignment(Qt.AlignmentFlag.AlignTop)

        # أزرار الشريط الجانبي
        self.settings_button = self.create_sidebar_button(
            resource_path("ui/icons/settings.jpg"), "إعدادات النظام")
        self.adduser_button = self.create_sidebar_button(
            resource_path("ui/icons/addUser.png"), "إضافة مستخدم")

        for SetSittings in [self.settings_button,self.adduser_button] :
            # ⭐️ نسمح للزر أن يكون قابل للتحديد (تفعيل/إلغاء)
            SetSittings.setCheckable(True)

            # ⭐️ تنسيق الزر مع حالات hover و checked
            SetSittings.setStyleSheet("""
                QPushButton {
                    background-color: transparent;
                    border: none;
                    padding: 0px;
                }
                QPushButton:hover {
                    background-color: #d0e3ff; /* لون أزرق خفيف عند التمرير */
                    border-radius: 2px;
                    border-bottom: 2px solid #007AFF;
                    padding: 0px;
                }
                QPushButton:checked {

                    border-bottom: 1px solid #007AFF; /* شريط سفلي أزرق عند التحديد */
                    padding: 0px;
                }
            """)
            sidebar_layout.addWidget(SetSittings)
            SetSittings.clicked.connect(self.open_settings_page)

        self.sidebar.setLayout(sidebar_layout)

        self.stacked_widget.addWidget(self.tabs)         # الصفحة الأولى: التابات
        self.stacked_widget.addWidget(self.settings_page)  # الصفحة الثانية: الإعدادات
        self.stacked_widget.addWidget(self.adduser_page)  # الصفحة الثانية: الإعدادات


        # ✅ تنسيق كامل
        main_layout = QHBoxLayout()
        main_layout.setContentsMargins(2,0,0,2)
        main_layout.setSpacing(2)  # ✅ المسافة بين العناصر صفر

        main_layout.addWidget(self.sidebar)
        main_layout.addWidget(self.stacked_widget)


        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

        self.setup_home_tab()




    def animate_page_transition(self, old_widget, new_widget):
        """ 🔹 أنيميشن انتقالي أنيق بين صفحتين مع حماية كاملة أثناء التحريك """
        if getattr(self, "is_animating", False):
            return  # 🔥 تجاهل لو فيه أنيميشن شغال

        self.is_animating = True

        # 🔥 إيقاف زر الإعدادات مؤقتًا
        self.adduser_button.setEnabled(False)
        self.settings_button.setEnabled(False)
        self.tabs.setEnabled(False)  

        width = self.stacked_widget.width()

        new_widget.setGeometry(width, 0, width, self.stacked_widget.height())
        new_widget.show()
        new_widget.raise_()

        new_animation = QPropertyAnimation(new_widget, b"pos")
        new_animation.setDuration(1000)
        new_animation.setStartValue(QPoint(width, 0))
        new_animation.setEndValue(QPoint(0, 0))
        new_animation.setEasingCurve(QEasingCurve.Type.OutCubic)

        old_animation = QPropertyAnimation(old_widget, b"pos")
        old_animation.setDuration(1000)
        old_animation.setStartValue(QPoint(0, 0))
        old_animation.setEndValue(QPoint(-width, 0))
        old_animation.setEasingCurve(QEasingCurve.Type.OutCubic)

        def on_animation_finished():
            self.stacked_widget.setCurrentWidget(new_widget)
            old_widget.move(0, 0)
            old_widget.hide()

            self.is_animating = False

            # 🔥 تفعيل الزر والتابات بعد الأنيميشن
            self.adduser_button.setEnabled(True)
            self.settings_button.setEnabled(True)
            self.tabs.setEnabled(True)

        new_animation.finished.connect(on_animation_finished)

        old_animation.start()
        new_animation.start()

        self.current_animation = (old_animation, new_animation)


    def animate_page_transition_V(self, old_widget, new_widget, active_button):
        """ 🔹 أنيميشن انتقالي رأسي مع تحكم بالأزرار """
        if getattr(self, "is_animating", False):
            return

        self.is_animating = True

        # 🔁 تعطيل الأزرار الأخرى وإلغاء تحديدها
        for button in [self.settings_button, self.adduser_button]:
            button.setEnabled(False)
            if button != active_button:
                button.setChecked(False)

        self.tabs.setEnabled(False)

        height = self.stacked_widget.height()

        new_widget.setGeometry(0, height, self.stacked_widget.width(), height)
        new_widget.show()
        new_widget.raise_()

        new_animation = QPropertyAnimation(new_widget, b"pos")
        new_animation.setDuration(1000)
        new_animation.setStartValue(QPoint(0, height))
        new_animation.setEndValue(QPoint(0, 0))
        new_animation.setEasingCurve(QEasingCurve.Type.OutCubic)

        old_animation = QPropertyAnimation(old_widget, b"pos")
        old_animation.setDuration(1000)
        old_animation.setStartValue(QPoint(0, 0))
        old_animation.setEndValue(QPoint(0, -height))
        old_animation.setEasingCurve(QEasingCurve.Type.OutCubic)

        def on_animation_finished():
            self.stacked_widget.setCurrentWidget(new_widget)
            old_widget.move(0, 0)
            old_widget.hide()

            self.is_animating = False

            # ✅ إعادة تفعيل كل الأزرار
            for button in [self.settings_button, self.adduser_button]:
                button.setEnabled(True)
                if button == active_button:
                    button.setChecked(True)

            self.tabs.setEnabled(True)

        new_animation.finished.connect(on_animation_finished)

        old_animation.start()
        new_animation.start()

        self.currentH_animation = (old_animation, new_animation)


    def open_settings_page(self):
        """ 🔹 لما نضغط زر الإعدادات ننتقل لصفحة الإعدادات بأنيميشن """
        if getattr(self, "is_animating", False):
            return  # 🔥 تجاهل الضغط أثناء أنيميشن
        current_index = self.tabs.currentIndex()
        
        if self.settings_button == self.sender() and not(self.stacked_widget.currentWidget()==self.settings_page) :

            try:
                if self.stacked_widget.currentWidget() != self.tabs :
                    self.animate_page_transition_V(self.stacked_widget.currentWidget(), self.settings_page,self.settings_button)
                    self.settings_page.replay_animation()  # ⬅️ إعادة تشغيل أنيميشن القائمة
                else :
                    self.animate_page_transition(self.stacked_widget.currentWidget(), self.settings_page)
                    self.settings_page.replay_animation()  # ⬅️ إعادة تشغيل أنيميشن القائمة
            except Exception as e:
                print(f"حدث خطأ أثناء التشغيل: {e}")

        elif self.adduser_button == self.sender() and not(self.stacked_widget.currentWidget()==self.adduser_page) :
            try:     
                if self.stacked_widget.currentWidget() != self.tabs :
                    self.animate_page_transition_V(self.stacked_widget.currentWidget(), self.adduser_page,self.adduser_button)
                    # self.settings_page.replay_animation()  # ⬅️ إعادة تشغيل أنيميشن القائمة
                else :
                    self.animate_page_transition(self.stacked_widget.currentWidget(), self.adduser_page)
                    # self.settings_page.replay_animation()  # ⬅️ إعادة تشغيل أنيميشن القائمة
            except Exception as e:
                print(f"حدث خطأ أثناء التشغيل: {e}")

        else:
            self.animate_page_transition(self.stacked_widget.currentWidget(), self.tabs)
            self.tabs.setCurrentIndex(current_index)

    def create_sidebar_button(self, icon_path, tooltip):
        """إنشاء زر جانبي مخصص"""
        button = QPushButton()
        button.setIcon(QIcon(icon_path))
        button.setIconSize(QSize(30, 30))
        button.setFixedSize(32, 35)
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        button.setToolTip(tooltip)
        return button

    def setup_home_tab(self):
        layout = QVBoxLayout()
        title = QLabel("🚀 مرحبًا بك في **سبرت منجر**")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)

        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(15)
        shadow.setColor(QColor("#ffcc00"))
        shadow.setOffset(3, 3)
        title.setGraphicsEffect(shadow)

        subtitle = QLabel("🔹 UPDATER DON **إدارة متجرك بكل سهولة واحترافية!** 🔹")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)

        layout.addWidget(title)
        layout.addWidget(subtitle)
        self.home_tab.setLayout(layout)

    def center_window(self):
        screen = self.screen()
        if screen is not None : 
            screen =  screen.geometry()
            window_size = self.geometry()

            x = (screen.width() - window_size.width()) // 2
            y = (screen.height() - window_size.height()) // 2

            self.move(x, y-30)

    def apply_styles(self):
        """ 🎨 تطبيق تنسيق عصري للواجهة """
        self.setStyleSheet("""
QMainWindow {
    background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1,
    stop:0 #F9F9F9, stop:1 #E3ECF5);
    color: #333;
    font-family: "Tajawal", "Cairo", sans-serif;
}

QLabel {
    color: #007AFF;
    font-weight: bold;
    font-size: 10px;
}

QTabWidget::pane {
    border: 2px solid #007AFF;
    border-radius: 10px;
    background: #FFFFFF;
    min-height: 10px;
}

QTabBar::tab {
    background: #E3ECF5;
    color: #333;
    padding: 5px 15px;
    margin: 2px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: bold;
    min-height: 25px;
    height: 27px;
    text-align: center;
}

QTabBar::tab:selected {
    background: #007AFF;
    color: white;
    font-size: 14px;
    height: 29px;
}

QTabBar::tab:hover {
    background: #62A1FF;
    border-radius: 8px;
}
""")
        
